WordPress Plugin Template
=========================

A basic code template for creating a standards-compliant WordPress plugin